export default async function DashboardPage() {
  return (
    <section>
      <h1 className="text-2xl font-semibold">Dashboard</h1>
    </section>
  );
}
