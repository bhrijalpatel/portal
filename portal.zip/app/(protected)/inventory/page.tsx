export default function InventoryPage() {
  return (
    <section>
      <h1 className="text-2xl font-semibold">Inventory</h1>
    </section>
  );
}
